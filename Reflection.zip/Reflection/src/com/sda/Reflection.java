package com.sda;

import java.lang.reflect.Method;

public class Reflection {

    public static void main(String[] args) throws ClassNotFoundException {
        Method[] declaredMethods = Player.class.getDeclaredMethods();

        for (Method m : declaredMethods) {
            System.out.println(m.getName());
        }

        Class.forName("com.sda.Player");
    }
}

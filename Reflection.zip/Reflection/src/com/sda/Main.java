package com.sda;

public class Main {

    public static void main(String[] args) throws ClassNotFoundException, InterruptedException {
        x(1);
    }

    static int x(int n) {
        return x(n+1) * n;
    }
}

package com.sda;

public class Player {

    public String getName() {
        return "Joe";
    }

    public String getLastName() {
        return "Doe";
    }
}
